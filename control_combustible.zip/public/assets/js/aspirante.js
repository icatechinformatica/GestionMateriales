$(document).ready(function (){
    $("#fecha_nacimiento").datepicker({
        changeMonth: true,
        changeYear: true,
        format: 'dd-mm-yy'
    });
});
